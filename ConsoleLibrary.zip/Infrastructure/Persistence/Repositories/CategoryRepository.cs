﻿using Domain.Models;

namespace Infrastructure.Persistence.Repositories
{
    public class CategoryRepository : Repository<Category>
    {
    }
}
