﻿using Domain.Models;

namespace Infrastructure.Persistence.Repositories
{
    public class BookRepository : Repository<Book>
    {
    }
}
