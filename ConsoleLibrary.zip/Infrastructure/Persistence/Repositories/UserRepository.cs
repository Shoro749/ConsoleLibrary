﻿using Domain.Models;

namespace Infrastructure.Persistence.Repositories
{
    public class UserRepository : Repository<User>
    {
    }
}
