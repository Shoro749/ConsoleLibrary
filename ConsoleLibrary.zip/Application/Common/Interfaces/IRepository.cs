﻿namespace Application.Common.Interfaces
{
    public interface IRepository<T>
    {
        IReadOnlyList<T> GetAll();
        T? GetById(Guid id);
        T Add(T item);
        T Update(T item);
        void Delete(Guid id);
    }
}
