﻿using Application.Common.Interfaces;
using Application.Services.Abstract;
using Domain.Models;

namespace Application.Services.Implementation
{
    public sealed class NotificationService : INotificationService, IDisposable
    {
        private readonly IBookService _bookService;
        private readonly IUserService _userService;
        private readonly IEmailService _emailService;
        private bool _disposed;

        public NotificationService(
            IBookService bookService,
            IUserService userService,
            IEmailService emailService)
        {
            _bookService = bookService ?? throw new ArgumentNullException(nameof(bookService));
            _userService = userService ?? throw new ArgumentNullException(nameof(userService));
            _emailService = emailService ?? throw new ArgumentNullException(nameof(emailService));

            _bookService.BookAdded += OnBookAdded;
        }

        private void OnBookAdded(Book book)
        {
            Notify(book);
        }

        public void Notify(Book book)
        {
            ArgumentNullException.ThrowIfNull(book);

            var subscribers = _userService.GetSubscribers(book.CategoryId);
            string categoryName = book.Category?.Name ?? "your subscribed category";
            string subject = $"New book in {categoryName}";
            string body = $"A new book has been added to the library:\n" +
                          $"Title: {book.Title}\n" +
                          $"Author: {book.Author}\n" +
                          $"Pages: {book.Pages}\n" +
                          $"Category: {categoryName}";

            foreach (var user in subscribers) _emailService.Send(user.Email, subject, body);
        }

        public void Dispose()
        {
            if (_disposed) return;

            _bookService.BookAdded -= OnBookAdded;
            _disposed = true;
        }
    }
}
